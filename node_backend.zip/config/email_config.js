exports.email_auth=function(){
    return{
        email:"esoftdev1@gmail.com",
        password:"1234bigi"
    }
}